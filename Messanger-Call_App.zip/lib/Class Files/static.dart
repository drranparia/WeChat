class Statics {
  static const String appSign =
      '2fd90d6820c7669f46d01dca1f1e6f485b5399eb43a36f567773c4debf7012b2';
  static const int appID = 1122373021; //Your appID
}
